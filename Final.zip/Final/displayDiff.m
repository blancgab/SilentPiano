function [ output_args ] = displayDiff(frame)








end

