# SilentPiano
Silent Piano Digital Image Processing Project

Run Main.m